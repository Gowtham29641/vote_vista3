const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const file = process.env.DB_FILE || './database/votevista.sqlite';
const resolved = path.resolve(process.cwd(), file);
fs.mkdirSync(path.dirname(resolved), { recursive: true });
const db = new Database(resolved);
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'student' CHECK(role IN ('student','admin')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS elections (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('draft','open','closed')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS positions (
 id INTEGER PRIMARY KEY,
 election_id INTEGER NOT NULL REFERENCES elections(id) ON DELETE CASCADE,
 name TEXT NOT NULL, UNIQUE(election_id,name), UNIQUE(id,election_id)
);
CREATE TABLE IF NOT EXISTS candidates (
 id INTEGER PRIMARY KEY,
 position_id INTEGER NOT NULL REFERENCES positions(id) ON DELETE CASCADE,
 name TEXT NOT NULL, department TEXT NOT NULL, symbol TEXT NOT NULL,
 manifesto TEXT NOT NULL, UNIQUE(id,position_id)
);

/* Identity is stored separately from anonymous ballot selections.
   There is deliberately no voter_id or receipt_id column in votes. */
CREATE TABLE IF NOT EXISTS ballot_submissions (
 id INTEGER PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id),
 election_id INTEGER NOT NULL REFERENCES elections(id),
 receipt_id TEXT NOT NULL UNIQUE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id,election_id)
);
CREATE TABLE IF NOT EXISTS votes (
 id INTEGER PRIMARY KEY,
 election_id INTEGER NOT NULL,
 position_id INTEGER NOT NULL,
 candidate_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(position_id,election_id) REFERENCES positions(id,election_id),
 FOREIGN KEY(candidate_id,position_id) REFERENCES candidates(id,position_id)
);
CREATE INDEX IF NOT EXISTS idx_votes_election_position ON votes(election_id,position_id);
CREATE INDEX IF NOT EXISTS idx_votes_candidate ON votes(candidate_id);
CREATE INDEX IF NOT EXISTS idx_ballot_submissions_user ON ballot_submissions(user_id,election_id);
CREATE TABLE IF NOT EXISTS polls (
 id INTEGER PRIMARY KEY, creator_id INTEGER NOT NULL REFERENCES users(id),
 question TEXT NOT NULL, deadline TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS poll_options (
 id INTEGER PRIMARY KEY, poll_id INTEGER NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
 label TEXT NOT NULL, UNIQUE(id,poll_id)
);
CREATE TABLE IF NOT EXISTS poll_votes (
 id INTEGER PRIMARY KEY,
 poll_id INTEGER NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
 option_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(option_id,poll_id) REFERENCES poll_options(id,poll_id),
 UNIQUE(poll_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_polls_created ON polls(id DESC);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY, actor_id INTEGER REFERENCES users(id),
 action TEXT NOT NULL, details TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(id DESC);
`);

module.exports = db;
