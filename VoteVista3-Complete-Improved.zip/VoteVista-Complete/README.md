# VoteVista – CampusVote Shield

A full-stack academic demonstration of a campus election platform. It retains the original VoteVista visual identity and adds an Express API, SQLite persistence, server-side vote rules, authentication, poll management, receipt verification and automated database testing.

> **Important limitation:** This is an educational prototype, not a certified or legally suitable election system. A browser-based demo login and a SHA-256 receipt do not establish real-world voter identity, ballot secrecy, end-to-end verifiability or election certification. Do not use it for binding elections or sensitive personal data.

## Technology
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Application/API: Node.js 20+, Express
- Database: SQLite through better-sqlite3
- Security controls: bcrypt password hashing, signed expiring JWTs, role checks, server-side constraints, parameterized SQL, Helmet, CORS allow-list, request-size limits and rate limiting
- Tests: Node.js built-in test runner

## Architecture
1. **Presentation layer** – `frontend/` serves the UI and calls `/api` endpoints.
2. **Application layer** – `backend/server.js`, `backend/routes/api.js` and middleware implement validation, authentication and business rules.
3. **Data layer** – `backend/config/database.js` defines relational tables, foreign keys, indexes and unique constraints in SQLite.

## Requirements
- Node.js 20 or newer and npm.
- Build tools may be needed by your operating system to install `better-sqlite3` if a prebuilt binary is unavailable.

## Setup (Windows PowerShell)
```powershell
# 1. Open this project folder in VS Code / terminal
npm install

# 2. Create your environment file
Copy-Item .env.example .env

# 3. Edit .env and replace JWT_SECRET with a long random secret (at least 32 characters)
# Example PowerShell secret generation:
[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(48))

# 4. Seed demo accounts and election candidates
npm run seed

# 5. Start the application
npm start
```
Open **http://localhost:3000**. Do not open `index.html` directly or use Live Server; the Express server provides the API and static files.

## Demo accounts
- Student: `student1@votevista.test` / `Student@123`
- Second student: `student2@votevista.test` / `Student@123`
- Administrator: `admin@votevista.test` / `Admin@123`

These are public demo credentials. Replace/remove them and implement an institution-controlled identity provider before any real deployment. The seed script does not overwrite existing accounts.

## API overview
| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | Public, rate limited | Authenticate demo account |
| GET | `/api/me` | Signed-in | Current account |
| GET | `/api/election` | Public | Election, positions, candidates and totals |
| POST | `/api/votes` | Student | Submit one complete ballot |
| GET | `/api/votes/mine` | Signed-in | Latest personal receipt |
| POST | `/api/receipts/verify` | Signed-in | Verify receipt hash against stored record |
| GET | `/api/polls` | Public | List polls and counts |
| POST | `/api/polls` | Signed-in | Create a community poll |
| POST | `/api/polls/:id/vote` | Signed-in | Vote once in a poll |
| GET | `/api/admin/overview` | Admin | Overview and recent audit events |
| GET | `/api/health` | Public | Health check |

Authenticated endpoints require `Authorization: Bearer <token>`.

## Voting rules
- Candidate choices are checked against the election and position on the server.
- A database transaction inserts the complete ballot atomically.
- A unique database constraint on `(user_id, election_id, position_id)` prevents a second vote for the same position, even if browser storage is cleared.
- Poll votes are constrained to one per account per poll.
- The frontend does not store vote totals or voting eligibility as the source of truth.

## Tests
```powershell
npm test
```
The included test verifies that SQLite rejects a duplicate vote for the same account, election and position. Add broader route-level and browser tests before production use.

## Data and configuration
- SQLite database is created at `database/votevista.sqlite` by default.
- Set `DB_FILE` to change its location.
- Set `PORT`, `JWT_SECRET`, `CLIENT_ORIGIN` and `NODE_ENV` in `.env`.
- Never commit `.env`, database files or production credentials.

## Current scope and future work
The demo includes student/admin roles, candidate selection, server-enforced duplicate prevention, database-backed results, community polls, audit events and receipts. Production readiness would additionally require institutional identity verification, independent security review, threat modelling, privacy/legal review, accessibility testing, backup/restore procedures, operational monitoring, stronger election governance, ballot secrecy design and comprehensive end-to-end testing.


## Attempt 2 improvements

This revision directly addresses the evaluator's page 4 feedback:
- Added bounded pagination (`page`, `limit`, maximum 50) to community polls and the admin audit feed.
- Added load-more controls in the UI for both lists.
- Added structured JSON application logging with timestamps, severity and event names.
- Expanded automated tests for anonymous ballot schema, one-ballot-per-election enforcement, poll-vote uniqueness, option ownership and pagination metadata.
- Refactored the API route module into readable, consistently formatted route handlers.
- Strengthened relational integrity with composite foreign keys and supporting indexes.

### Ballot privacy model
Voter eligibility/participation is recorded in `ballot_submissions`. Candidate selections are stored in `votes`, which intentionally has no `user_id` or `receipt_id` field. The receipt record is kept separately from the candidate selections. This is a better separation than directly storing a voter identifier beside each candidate choice, but it is **not** a cryptographically anonymous or independently certified election system. The administrator audit trail still records administrative/security events. Do not use this academic demo for real elections.

### Database note
The updated schema is designed for a fresh demo database. If you have an older local `database/votevista.sqlite` from an earlier VoteVista version, back it up and remove that demo database before running `npm run seed`; the seed command will then create the new schema and demo data. Do not delete a database containing data you need.

### Verification
Run:
```bash
npm install
npm test
npm run seed
npm start
```
Open `/api/health` and verify it returns `{ "status": "ok", "service": "VoteVista API" }`. Then test the student and admin workflows using the submission checklist.
