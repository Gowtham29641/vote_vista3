# Submission checklist

- [ ] Install dependencies with `npm install`.
- [ ] Copy `.env.example` to `.env` and set a unique 32+ character `JWT_SECRET`.
- [ ] Run `npm run seed`.
- [ ] Run `npm test` and retain the output (anonymous-ballot, poll integrity and pagination tests).
- [ ] Start with `npm start` and open `http://localhost:3000`.
- [ ] Test student sign-in, candidate selection, ballot submission and duplicate rejection.
- [ ] Test a second account, community poll creation and duplicate poll-vote rejection.
- [ ] Test admin-only overview and paginated audit feed using the admin demo account.
- [ ] Test the Load more controls for community polls and audit events.
- [ ] Confirm the `votes` table has no `user_id` or `receipt_id` columns.
- [ ] Confirm structured JSON logs appear in the server terminal.
- [ ] Check browser console and server terminal for errors.
- [ ] Upload the ZIP source project to LetzProject (not a screenshot or static HTML export).
- [ ] Include genuine screenshots and a short demo video if the submission portal permits.

A high score cannot be guaranteed; the evaluator decides based on the actual rubric, execution, documentation and evidence.
