const jwt = require('jsonwebtoken');
function authenticate(req,res,next){
  const header=req.get('authorization')||''; const token=header.startsWith('Bearer ')?header.slice(7):null;
  if(!token) return res.status(401).json({error:'Please sign in first.'});
  try { req.user=jwt.verify(token,process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'Session expired. Please sign in again.'}); }
}
function requireAdmin(req,res,next){ if(req.user?.role!=='admin') return res.status(403).json({error:'Administrator access required.'}); next(); }
module.exports={authenticate,requireAdmin};
