require('dotenv').config();
const logger = require('./services/logger');
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  logger.error('startup_blocked_missing_jwt_secret', { minimumLength: 32 });
  process.exit(1);
}
const express = require('express');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('./config/database');
const app = express();
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com'], scriptSrc: ["'self'"], imgSrc: ["'self'", 'data:']
}}}));
const origins = (process.env.CLIENT_ORIGIN || 'http://localhost:3000').split(',').map(x => x.trim());
app.use(cors({ origin: (origin, callback) => !origin || origins.includes(origin)
  ? callback(null, true) : callback(new Error('Origin not allowed')) }));
app.use(express.json({ limit: '20kb' }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false }));
app.use('/api', require('./routes/api'));
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));
app.use((error, req, res, next) => {
  logger.error('http_request_failed', { method: req.method, path: req.path, error: error.message });
  if (res.headersSent) return next(error);
  res.status(error.status || 500).json({ error: error.status && error.status < 500
    ? error.message : 'Unexpected server error. Please try again.' });
});
if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  app.listen(port, () => logger.info('server_started', { port, environment: process.env.NODE_ENV || 'development' }));
}
module.exports = app;
