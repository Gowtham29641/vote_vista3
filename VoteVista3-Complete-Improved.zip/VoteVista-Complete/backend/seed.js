require('dotenv').config();
const bcrypt=require('bcryptjs'); const db=require('./config/database');
const addUser=db.prepare('INSERT OR IGNORE INTO users(name,email,password_hash,role) VALUES(?,?,?,?)');
addUser.run('Demo Student One','student1@votevista.test',bcrypt.hashSync('Student@123',12),'student');
addUser.run('Demo Student Two','student2@votevista.test',bcrypt.hashSync('Student@123',12),'student');
addUser.run('VoteVista Administrator','admin@votevista.test',bcrypt.hashSync('Admin@123',12),'admin');
let election=db.prepare('SELECT id FROM elections LIMIT 1').get();
if(!election){ const info=db.prepare('INSERT INTO elections(title,status) VALUES(?,?)').run('Campus Election 2026','open'); election={id:info.lastInsertRowid};
 const positions=[['College President',[['Aarav Sharma','Computer Science','A','Promote student innovation and improve campus facilities.'],['Priya Reddy','Electronics','P','Focus on student welfare and inclusive campus activities.'],['Rahul Kumar','Mechanical','R','Improve sports facilities and support student clubs.'],['Sneha Patel','Information Technology','S','Build a creative campus with more technical events.']]],['Vice President',[['Arjun Verma','Computer Science','A','Improve student coordination and academic collaboration.'],['Meera Nair','Civil Engineering','M','Create a welcoming environment for all students.']]],['Sports Secretary',[['Kiran Das','Physical Education','K','Expand sports facilities and campus tournaments.'],['Ananya Rao','Computer Science','A','Support inclusive sports and student fitness events.']]]];
 const p=db.prepare('INSERT INTO positions(election_id,name) VALUES(?,?)'); const c=db.prepare('INSERT INTO candidates(position_id,name,department,symbol,manifesto) VALUES(?,?,?,?,?)');
 for(const [name,candidates] of positions){const id=p.run(election.id,name).lastInsertRowid; for(const x of candidates)c.run(id,...x);}
}
console.log('VoteVista database seeded. Demo student: student1@votevista.test / Student@123; admin: admin@votevista.test / Admin@123');
