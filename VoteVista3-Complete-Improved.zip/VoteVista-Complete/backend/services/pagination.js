function parsePagination(query = {}) {
  const pageRaw = Number.parseInt(query.page ?? '1', 10);
  const limitRaw = Number.parseInt(query.limit ?? '10', 10);
  const page = Number.isSafeInteger(pageRaw) && pageRaw > 0 ? pageRaw : 1;
  const limit = Number.isSafeInteger(limitRaw) ? Math.min(50, Math.max(1, limitRaw)) : 10;
  return { page, limit, offset: (page - 1) * limit };
}
function pageInfo(total, page, limit) {
  return { page, limit, total, totalPages: Math.ceil(total / limit), hasNext: page * limit < total, hasPrevious: page > 1 };
}
module.exports = { parsePagination, pageInfo };
