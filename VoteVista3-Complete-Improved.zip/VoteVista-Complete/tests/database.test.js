const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('database enforces one ballot per student and keeps ballot choices anonymous', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vv-test-'));
  process.env.DB_FILE = path.join(dir, 'test.sqlite');
  const db = require('../backend/config/database');
  try {
    const user = db.prepare("INSERT INTO users(name,email,password_hash) VALUES('Test','test@example.test','hash')").run().lastInsertRowid;
    const election = db.prepare("INSERT INTO elections(title,status) VALUES('Test election','open')").run().lastInsertRowid;
    const position = db.prepare('INSERT INTO positions(election_id,name) VALUES(?,?)').run(election,'President').lastInsertRowid;
    const candidate = db.prepare('INSERT INTO candidates(position_id,name,department,symbol,manifesto) VALUES(?,?,?,?,?)').run(position,'Candidate','CS','C','Test').lastInsertRowid;
    db.prepare('INSERT INTO ballot_submissions(user_id,election_id,receipt_id) VALUES(?,?,?)').run(user,election,'receipt-one');
    assert.throws(() => db.prepare('INSERT INTO ballot_submissions(user_id,election_id,receipt_id) VALUES(?,?,?)').run(user,election,'receipt-two'), /UNIQUE constraint failed/);
    db.prepare('INSERT INTO votes(election_id,position_id,candidate_id) VALUES(?,?,?)').run(election,position,candidate);
    const voteColumns = db.prepare('PRAGMA table_info(votes)').all().map(column => column.name);
    assert.equal(voteColumns.includes('user_id'), false);
    assert.equal(voteColumns.includes('receipt_id'), false);
    assert.throws(() => db.prepare('INSERT INTO votes(election_id,position_id,candidate_id) VALUES(?,?,?)').run(election,position,99999));
    const poll = db.prepare('INSERT INTO polls(creator_id,question) VALUES(?,?)').run(user,'Campus food choices?').lastInsertRowid;
    const option = db.prepare('INSERT INTO poll_options(poll_id,label) VALUES(?,?)').run(poll,'Option A').lastInsertRowid;
    const otherPoll = db.prepare('INSERT INTO polls(creator_id,question) VALUES(?,?)').run(user,'Other question?').lastInsertRowid;
    const otherOption = db.prepare('INSERT INTO poll_options(poll_id,label) VALUES(?,?)').run(otherPoll,'Option B').lastInsertRowid;
    const insertPollVote = db.prepare('INSERT INTO poll_votes(poll_id,option_id,user_id) VALUES(?,?,?)');
    insertPollVote.run(poll,option,user);
    assert.throws(() => insertPollVote.run(poll,option,user), /UNIQUE constraint failed/);
    assert.throws(() => insertPollVote.run(poll,otherOption,user), /FOREIGN KEY constraint failed/);
  } finally {
    db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('pagination is bounded and reports page metadata', () => {
  const { parsePagination, pageInfo } = require('../backend/services/pagination');
  assert.deepEqual(parsePagination({ page: '-4', limit: '500' }), { page: 1, limit: 50, offset: 0 });
  assert.deepEqual(pageInfo(23, 2, 10), { page: 2, limit: 10, total: 23, totalPages: 3, hasNext: true, hasPrevious: true });
});
