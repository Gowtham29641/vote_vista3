const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('../config/database');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { parsePagination, pageInfo } = require('../services/pagination');
const logger = require('../services/logger');
const router = express.Router();

const audit = (actor, action, details = '') =>
  db.prepare('INSERT INTO audit_logs(actor_id,action,details) VALUES(?,?,?)').run(actor, action, details);
const safeInt = value => Number.isSafeInteger(Number(value)) && Number(value) > 0;
const receiptHash = (receiptId, time) =>
  crypto.createHash('sha256').update(`${receiptId}|${time}`).digest('hex');

router.post('/auth/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password || email.length > 254 || password.length > 128)
      return res.status(400).json({ error: 'Enter a valid email and password.' });
    const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if (!user || !await bcrypt.compare(password, user.password_hash))
      return res.status(401).json({ error: 'Invalid email or password.' });
    const token = jwt.sign({ id: user.id, name: user.name, role: user.role },
      process.env.JWT_SECRET, { expiresIn: '4h', issuer: 'votevista' });
    audit(user.id, 'LOGIN');
    logger.info('authentication_succeeded', { userId: user.id, role: user.role });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) { next(error); }
});
router.get('/me', authenticate, (req, res) => res.json({ user: req.user }));

router.get('/election', (req, res) => {
  const election = db.prepare('SELECT * FROM elections ORDER BY id DESC LIMIT 1').get();
  if (!election) return res.status(404).json({ error: 'No election configured.' });
  const positions = db.prepare('SELECT * FROM positions WHERE election_id=?').all(election.id).map(position => ({
    ...position,
    candidates: db.prepare(`SELECT c.id,c.name,c.department,c.symbol,c.manifesto,
      (SELECT COUNT(*) FROM votes v WHERE v.candidate_id=c.id AND v.election_id=?) AS votes
      FROM candidates c WHERE c.position_id=? ORDER BY c.id`).all(election.id, position.id)
  }));
  const totalVotes = db.prepare('SELECT COUNT(*) AS n FROM ballot_submissions WHERE election_id=?').get(election.id).n;
  res.json({ election, positions, totalVotes });
});

router.post('/votes', authenticate, (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Only student accounts may submit a ballot.' });
  const election = db.prepare("SELECT * FROM elections WHERE status='open' ORDER BY id DESC LIMIT 1").get();
  if (!election) return res.status(409).json({ error: 'There is no open election.' });
  const selections = req.body.selections;
  if (!selections || typeof selections !== 'object' || Array.isArray(selections))
    return res.status(400).json({ error: 'Select one candidate for every position.' });
  const positions = db.prepare('SELECT id FROM positions WHERE election_id=?').all(election.id);
  if (Object.keys(selections).length !== positions.length ||
      positions.some(p => !safeInt(selections[p.id])))
    return res.status(400).json({ error: 'A valid candidate selection is required for every position.' });
  try {
    const submit = db.transaction(() => {
      const receiptId = `VV-${crypto.randomUUID()}`;
      const created = db.prepare('INSERT INTO ballot_submissions(user_id,election_id,receipt_id) VALUES(?,?,?)')
        .run(req.user.id, election.id, receiptId);
      const addVote = db.prepare('INSERT INTO votes(election_id,position_id,candidate_id) VALUES(?,?,?)');
      for (const position of positions) {
        const candidateId = Number(selections[position.id]);
        const valid = db.prepare('SELECT id FROM candidates WHERE id=? AND position_id=?').get(candidateId, position.id);
        if (!valid) throw new Error('INVALID_CANDIDATE');
        addVote.run(election.id, position.id, candidateId);
      }
      audit(req.user.id, 'VOTE_SUBMITTED', receiptId);
      return { receiptId, time: db.prepare('SELECT created_at FROM ballot_submissions WHERE id=?').get(created.lastInsertRowid).created_at };
    });
    const result = submit();
    logger.info('anonymous_ballot_recorded', { electionId: election.id, receiptId: result.receiptId });
    res.status(201).json({ receipt: { receiptId: result.receiptId, student: req.user.name,
      status: 'Recorded', time: result.time, hash: receiptHash(result.receiptId, result.time) } });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE')
      return res.status(409).json({ error: 'A ballot has already been submitted for this election.' });
    if (error.message === 'INVALID_CANDIDATE')
      return res.status(400).json({ error: 'Invalid candidate selection.' });
    throw error;
  }
});

router.get('/votes/mine', authenticate, (req, res) => {
  const row = db.prepare(`SELECT receipt_id AS receiptId, created_at AS time
    FROM ballot_submissions WHERE user_id=? ORDER BY id DESC LIMIT 1`).get(req.user.id);
  if (!row) return res.json({ receipt: null });
  res.json({ receipt: { ...row, student: req.user.name, status: 'Recorded', hash: receiptHash(row.receiptId, row.time) } });
});
router.post('/receipts/verify', authenticate, (req, res) => {
  const id = String(req.body.receiptId || '');
  const row = db.prepare('SELECT receipt_id AS receiptId,created_at AS time FROM ballot_submissions WHERE receipt_id=? AND user_id=?')
    .get(id, req.user.id);
  if (!row) return res.status(404).json({ valid: false, error: 'Receipt not found for this account.' });
  res.json({ valid: true, hash: receiptHash(row.receiptId, row.time) });
});

router.get('/polls', (req, res) => {
  const { page, limit, offset } = parsePagination(req.query);
  const total = db.prepare('SELECT COUNT(*) AS n FROM polls').get().n;
  const polls = db.prepare('SELECT * FROM polls ORDER BY id DESC LIMIT ? OFFSET ?').all(limit, offset).map(poll => ({
    ...poll, options: db.prepare(`SELECT o.id,o.label,
      (SELECT COUNT(*) FROM poll_votes v WHERE v.option_id=o.id) AS votes
      FROM poll_options o WHERE o.poll_id=? ORDER BY o.id`).all(poll.id)
  }));
  res.json({ polls, pagination: pageInfo(total, page, limit) });
});
router.post('/polls', authenticate, (req, res) => {
  const question = String(req.body.question || '').trim();
  const first = String(req.body.optionOne || '').trim();
  const second = String(req.body.optionTwo || '').trim();
  const deadline = req.body.deadline || null;
  if (question.length < 8 || question.length > 180 || !first || !second ||
      first.length > 80 || second.length > 80 || first.toLowerCase() === second.toLowerCase())
    return res.status(400).json({ error: 'Enter a question (8–180 characters) and two different options.' });
  if (deadline && (!Number.isFinite(Date.parse(deadline)) || Date.parse(deadline) <= Date.now()))
    return res.status(400).json({ error: 'Choose a future closing date.' });
  const id = db.transaction(() => {
    const pollId = db.prepare('INSERT INTO polls(creator_id,question,deadline) VALUES(?,?,?)')
      .run(req.user.id, question, deadline).lastInsertRowid;
    const add = db.prepare('INSERT INTO poll_options(poll_id,label) VALUES(?,?)');
    add.run(pollId, first); add.run(pollId, second); return pollId;
  })();
  audit(req.user.id, 'POLL_CREATED', String(id));
  res.status(201).json({ id });
});
router.post('/polls/:id/vote', authenticate, (req, res) => {
  if (!safeInt(req.params.id) || !safeInt(req.body.optionId))
    return res.status(400).json({ error: 'A valid poll and option are required.' });
  const poll = db.prepare('SELECT * FROM polls WHERE id=?').get(Number(req.params.id));
  if (!poll) return res.status(404).json({ error: 'Poll not found.' });
  if (poll.deadline && Date.parse(poll.deadline) <= Date.now())
    return res.status(409).json({ error: 'This poll is closed.' });
  try {
    const result = db.prepare(`INSERT INTO poll_votes(poll_id,option_id,user_id)
      SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM poll_options WHERE id=? AND poll_id=?)`)
      .run(poll.id, Number(req.body.optionId), req.user.id, poll.id, Number(req.body.optionId), poll.id);
    if (!result.changes) return res.status(400).json({ error: 'Choose a valid option for this poll.' });
    res.status(201).json({ message: 'Your poll response was recorded.' });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE')
      return res.status(409).json({ error: 'You have already voted in this poll.' });
    throw error;
  }
});
router.get('/admin/overview', authenticate, requireAdmin, (req, res) => {
  const users = db.prepare('SELECT COUNT(*) n FROM users').get().n;
  const votes = db.prepare('SELECT COUNT(*) n FROM ballot_submissions').get().n;
  const polls = db.prepare('SELECT COUNT(*) n FROM polls').get().n;
  const { page, limit, offset } = parsePagination(req.query);
  const totalLogs = db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n;
  const logs = db.prepare(`SELECT action,details,created_at FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?`).all(limit, offset);
  res.json({ users, votes, polls, logs, pagination: pageInfo(totalLogs, page, limit) });
});
router.get('/health', (req, res) => res.json({ status: 'ok', service: 'VoteVista API' }));
module.exports = router;
