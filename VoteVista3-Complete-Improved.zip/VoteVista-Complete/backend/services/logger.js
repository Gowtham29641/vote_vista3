const levels = { error: 0, warn: 1, info: 2 };
const configured = process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug');
function write(level, message, metadata = {}) {
  if ((levels[level] ?? 3) > (levels[configured] ?? 2)) return;
  const record = { timestamp: new Date().toISOString(), level, message, ...metadata };
  const line = JSON.stringify(record);
  (level === 'error' ? console.error : level === 'warn' ? console.warn : console.log)(line);
}
module.exports = {
  info: (message, metadata) => write('info', message, metadata),
  warn: (message, metadata) => write('warn', message, metadata),
  error: (message, metadata) => write('error', message, metadata)
};
