const state={token:localStorage.getItem('vv_token'),user:null,election:null,selections:{},receipt:null,pollPage:1,auditPage:1};
const $=id=>document.getElementById(id);const api=async(path,options={})=>{const headers={'Content-Type':'application/json',...(options.headers||{})};if(state.token)headers.Authorization=`Bearer ${state.token}`;const response=await fetch(`/api${path}`,{...options,headers});const data=await response.json().catch(()=>({error:'Invalid server response.'}));if(!response.ok)throw new Error(data.error||'Request failed.');return data;};
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3000)}
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.page===id));$('pageTitle').textContent=({dashboard:'Dashboard',vote:'Cast Your Vote',results:'Live Results',polls:'Community Polls',receipt:'Vote Receipt',admin:'Administration'})[id]||'Dashboard';if(id==='results')loadElection();if(id==='polls')loadPolls();if(id==='receipt')loadReceipt();if(id==='admin')loadAdmin()};window.showPage=showPage;
document.querySelectorAll('.nav-link').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
$('themeToggle').addEventListener('click',()=>{document.body.classList.toggle('dark');const dark=document.body.classList.contains('dark');localStorage.setItem('vv_theme',dark?'dark':'light');$('themeToggle').textContent=dark?'☀ Light Mode':'☾ Dark Mode'});if(localStorage.getItem('vv_theme')==='dark'){document.body.classList.add('dark');$('themeToggle').textContent='☀ Light Mode'}
function setUser(user){state.user=user;$('studentDisplay').textContent=user?`${user.name} · ${user.role}`:'Guest Student';$('logoutBtn').hidden=!user;$('adminNav').hidden=user?.role!=='admin';$('votingArea').classList.toggle('hidden',!user||user.role!=='student')}
$('loginBtn').addEventListener('click',async()=>{try{const data=await api('/auth/login',{method:'POST',body:JSON.stringify({email:$('email').value,password:$('password').value})});state.token=data.token;localStorage.setItem('vv_token',state.token);setUser(data.user);$('loginMessage').textContent='Verified. You can now select candidates.';toast('Signed in successfully.');await loadElection()}catch(e){toast(e.message)}});
$('logoutBtn').addEventListener('click',()=>{state.token=null;localStorage.removeItem('vv_token');setUser(null);state.selections={};toast('Signed out.')});
async function restoreSession(){if(!state.token)return;try{const d=await api('/me');setUser(d.user)}catch{state.token=null;localStorage.removeItem('vv_token');setUser(null)}}
async function loadElection(){try{const d=await api('/election');state.election=d;$('totalVotes').textContent=d.totalVotes;$('resultTotal').textContent=d.totalVotes;$('positionCount').textContent=d.positions.length;$('candidateCount').textContent=d.positions.reduce((n,p)=>n+p.candidates.length,0);renderCandidates(d.positions);renderResults(d.positions)}catch(e){toast(e.message)}}
function make(tag,cls,text){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el}
function renderCandidates(positions){for(const p of positions){const box=$(({ 'College President':'presidentCandidates','Vice President':'viceCandidates','Sports Secretary':'sportsCandidates'})[p.name]);if(!box)continue;box.replaceChildren();for(const c of p.candidates){const card=make('div','candidate-card'+(state.selections[p.id]===c.id?' selected':''));const top=make('div','candidate-top');top.append(make('div','candidate-avatar',c.symbol));const info=make('div');info.append(make('h3','',c.name),make('p','',c.department));top.append(info);card.append(top,make('p','',c.manifesto));const btn=make('button','select-btn',state.selections[p.id]===c.id?'✓ Selected':'Select Candidate');btn.disabled=!state.user||state.user.role!=='student';btn.addEventListener('click',()=>{state.selections[p.id]=c.id;renderCandidates(positions)});card.append(btn);box.append(card)}}}
$('submitVote').addEventListener('click',async()=>{if(!state.user){toast('Sign in first.');return}if(!state.election||Object.keys(state.selections).length!==state.election.positions.length){toast('Select one candidate for every position.');return}if(!confirm('Submit your ballot? Each position can only be submitted once.'))return;try{const d=await api('/votes',{method:'POST',body:JSON.stringify({selections:state.selections})});state.receipt=d.receipt;state.selections={};toast('Ballot recorded successfully.');showPage('receipt');displayReceipt(d.receipt);await loadElection()}catch(e){toast(e.message)}});
function renderResults(positions){const box=$('resultsContainer');box.replaceChildren();for(const p of positions){const section=make('div','result-race');section.append(make('h3','',p.name));const total=p.candidates.reduce((n,c)=>n+c.votes,0);for(const c of p.candidates){const row=make('div','result-row'),info=make('div','result-info');info.append(make('strong','',c.name),make('span','',`${c.votes} votes · ${(total?c.votes/total*100:0).toFixed(1)}%`));const track=make('div','result-track'),fill=make('div','result-fill');fill.style.width=`${total?c.votes/total*100:0}%`;track.append(fill);row.append(info,track);section.append(row)}box.append(section)}}
$('createPoll').addEventListener('click',async()=>{try{await api('/polls',{method:'POST',body:JSON.stringify({question:$('pollQuestion').value,optionOne:$('optionOne').value,optionTwo:$('optionTwo').value,deadline:$('pollDeadline').value||null})});$('pollQuestion').value=$('optionOne').value=$('optionTwo').value=$('pollDeadline').value='';toast('Poll created.');loadPolls()}catch(e){toast(e.message)}});
async function loadPolls(append=false){
 try{
  if(!append){state.pollPage=1;$('pollList').replaceChildren()}
  const d=await api(`/polls?page=${state.pollPage}&limit=6`);
  const box=$('pollList');
  for(const p of d.polls){
   const card=make('div','poll-card');card.append(make('h3','',p.question),make('small','',p.deadline?`Closes ${new Date(p.deadline).toLocaleString()}`:'No closing date'));
   for(const o of p.options){
    const row=make('div','poll-option');row.append(make('span','',`${o.label} · ${o.votes} votes`));
    const b=make('button','','Vote');b.disabled=!state.user||!!(p.deadline&&Date.parse(p.deadline)<=Date.now());
    b.addEventListener('click',async()=>{try{await api(`/polls/${p.id}/vote`,{method:'POST',body:JSON.stringify({optionId:o.id})});toast('Poll response recorded.');loadPolls()}catch(e){toast(e.message)}});
    row.append(b);card.append(row);
   }
   box.append(card);
  }
  $('loadMorePolls').hidden=!d.pagination.hasNext;
  if(append)state.pollPage++;
 }catch(e){toast(e.message)}
}
$('loadMorePolls').addEventListener('click',()=>loadPolls(true));
function displayReceipt(r){state.receipt=r;$('receiptStudent').textContent=r.student;$('receiptStatus').textContent=r.status;$('receiptTime').textContent=r.time;$('receiptId').textContent=r.receiptId;$('receiptHash').textContent=r.hash}
async function loadReceipt(){if(!state.user)return;try{const d=await api('/votes/mine');if(d.receipt)displayReceipt(d.receipt)}catch(e){toast(e.message)}}
$('verifyReceipt').addEventListener('click',async()=>{if(!state.receipt){toast('No receipt to verify.');return}try{const d=await api('/receipts/verify',{method:'POST',body:JSON.stringify({receiptId:state.receipt.receiptId})});$('receiptVerifyMessage').textContent=d.valid&&d.hash===state.receipt.hash?'Receipt verified against the server record.':'Receipt verification failed.'}catch(e){$('receiptVerifyMessage').textContent=e.message}});
async function loadAdmin(append=false){
 if(state.user?.role!=='admin')return;
 try{
  if(!append){state.auditPage=1;$('adminAudit').replaceChildren()}
  const d=await api(`/admin/overview?page=${state.auditPage}&limit=8`);
  $('adminSummary').textContent=`Registered accounts: ${d.users} · Ballots recorded: ${d.votes} · Community polls: ${d.polls}.`;
  const list=$('adminAudit');
  for(const log of d.logs){const row=make('p','audit-entry');row.textContent=`${log.created_at} · ${log.action}${log.details?` · ${log.details}`:''}`;list.append(row)}
  $('loadMoreAudit').hidden=!d.pagination.hasNext;
  if(append)state.auditPage++;
 }catch(e){toast(e.message)}
}
$('refreshAdmin').addEventListener('click',()=>loadAdmin(false));
$('loadMoreAudit').addEventListener('click',()=>loadAdmin(true));
(async()=>{await restoreSession();await loadElection();await loadPolls();await loadReceipt()})();
